
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'karthicksaran',
  applicationName: 'lamda',
  appUid: 'pjgCcSg8ZkszBvkz3p',
  orgUid: '71d9e007-c8aa-40f1-938a-bdaf05fa2915',
  deploymentUid: '3a45a3f2-259d-4802-93e1-bdabb9d6749c',
  serviceName: 'lamda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'lamda-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/main.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}